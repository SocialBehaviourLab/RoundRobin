# main.py

# Round Robin scheduler
# This widget takes a list of PIDs and assigns them to conv ptrs, conv topics, chairs and rooms
# Rules:
# - each person must interact with each other person
# - each person must switch chairs after each conversation (used chairs may be revisited)
# - each person must discuss each conversation topic across the topic set (unless there is an
# odd number of conversations, in which case they will skip one pair of topics)
# - no person can discuss any specific conversation topic more than once
# - each conversation must include 1 topic from list A and 1 from list B

# Note: If you have not used a QR code generator before, you may need to install the "qrcode" package. 
# To do this, open a terminal and type "pip install qrcode".
# Other packages may also be missing from your setup. Your IDE should prompt you to install 
# any missing packages when you run the code.

import os
import pandas as pd
import numpy as np
import math
import random
from session_creator import *
from session_graph import *
from make_QR_code import *
from helper_functions import *

if not 'colaboratory' in locals():
    colaboratory = False

### CONVERSATION TOPIC PROMPTS

# Are you using one or more set(s) of topic prompts? 
# If so, the variable 'prompt' should be set to True (as it is currently set). If you wish to change this, 
# set the variable 'prompt' to False. These key words are capitalized.
# Note that True and False do not have quotes around them; Python treats them as a Boolean (on/off or true/false) data type.

prompt = True
if prompt: 
    # Define conversation topics (list A and list B - if using two conversation prompts). For a 3rd prompt, remove the 
    # hashtag from in front of list conversation_topics_C. Replace each topic with your own text.
    conversation_topics_A = ['Topic A1', 'Topic A2', 'Topic A3', 'Topic A4', 'Topic A5', 'Topic A6', 'Topic A7', 'Topic A8']
    conversation_topics_B = ['Topic B1', 'Topic B2', 'Topic B3', 'Topic B4', 'Topic B5', 'Topic B6', 'Topic B7', 'Topic B8']
    # conversation_topics_C = ['Topic C1', 'Topic C2', 'Topic C3', 'Topic C4', 'Topic C5', 'Topic C6', 'Topic C7', 'Topic C8']

    # This is a list of topic lists. If you wish to include or remove lists (e.g., conversation_topics_C from above), 
    # include/exclude the list names in the brackets below. Be sure to place a comma between each list you name.
    topic_lists = [conversation_topics_A, conversation_topics_B]
    num_topics = len(topic_lists) # how many discusison topics per round
    topic_dict = build_dict(topic_lists) # Builds a dictionary of topics and short labels (without spaces) for easy QR-code passing
                                         # DO NOT shuffle before building this list.

    # Shuffle topics to ensure random order each session (if you don't wish to randomize, put a hashtag in front of these lines); 
    # If using list C, remove the hashtag in front of this line to allow Python to see the code.
    random.shuffle(conversation_topics_A)
    random.shuffle(conversation_topics_B)
    # random.shuffle(conversation_topics_C)
else: 
    topic_lists = []
    num_topics = 0
    topic_dict = None
    
### MANIPULATION

# Are you using a manipulation that will be set individually for each participant on a round-by-round basis? 
# If so, the variable 'manip' should be set to True (it is currently set to False).
# This code presumes you have a very small number of manipulations that you want to compare across interactions.
# Realistically, this is probably not more than 2 or 3.
#
# If you are using a manipulation that is only applied to each person once, your pre-interaction 
# survey should code it with other session variables.
#
# Only one list of conditions allowed

manip = False
if manip:
    # Define manipulation conditions (A and B - if using two conditions). 
    conditions = ['Condition A', 'Condition B']
    condition_code = 'M' # or other single-letter code that will denote a manipulation label in the QR code data
    manip_dict = build_dict([conditions], condition_code) #  Builds a dictionary of condition codes and short labels for QR-code passing
else:
    conditions = []
    manip_dict = None

# Get session number and participant IDs (researcher enters these at the session start, based on actual attendance)
session_number = input('Please enter the full session number on the line below. \n')
done = False
correct = False
while not correct:
    attendance_ids = list()
    while not done:
        id_code = (input('Please enter a participant ID, including colour code. Press "d" when you are done. \n'))
        if str.upper(id_code) == 'D':
            done = True
        else:
            attendance_ids.append(str.upper(id_code))

    print(f'Current participants: {attendance_ids}')
    check_list = input('Is this list correct and complete? (y/n) \n')
    if str.upper(check_list) == 'Y':
        correct = True
    else:
        print('Start over. Rebuilding the list.')
        done = False


# Generate session based on above data
df, wait_room_chair = generate_session(session_number, attendance_ids, prompt, topic_lists, num_topics, topic_dict, manip, conditions, manip_dict)

# Output session summary
print(f'\nSession Number: {session_number}')
print(f'Total Interaction Rounds: {max(df['interaction_num'])}')
print(f'Total Active Participants: {len(attendance_ids)}')
print(f'Total Rooms in Use: {int(max(df['room']))}')
print(f'Chairs in Use: {np.unique(df['chair'])}')
print(f'Waiting room chair: {wait_room_chair}')
if prompt: 
    print(f'Active conversation topics from {num_topics} topic lists.')
if manip:
    print(f'Manipulation conditions active: {conditions}')   

# To correctly generate your QR codes, please replace the false URL in the variable 'quest_link' with the correct
# link to your own post-interaction questionnaire. 

quest_link = 'https://www.questionnairehost.com/questionnaire'

# If you would like to save a copy of the session map to a .png file within your current working directory
# change the variable 'save_figure' from False to True. If you are using Jupyter locally, you may need to install an
# extra library to two for this to work (if you have not already done so above). 
# To do that, see the second code cell from the top and follow the instructions.

save_figure = False

make_QR(df, wait_room_chair, num_prompts=num_topics, topic_dict=topic_dict, is_manip=manip, manip_dict=manip_dict, piq_link=quest_link)
make_round_graph(df, save_figure, colaboratory)