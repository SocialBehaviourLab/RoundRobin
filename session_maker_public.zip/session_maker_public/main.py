# main.py

# Round Robin scheduler
# This widget takes a list of PIDs and assigns them to conv ptrs, conv topics, chairs and rooms
# Rules:
# - each person must interact with each other person
# - each person must switch chairs after each conversation (used chairs may be revisited)
# - each person must discuss each conversation topic across the topic set (unless there is an
# odd number of conversations, in which case they will skip one pair of topics)
# - no person can discuss any specific conversation topic more than once
# - each conversation must include 1 topic from list A and 1 from list B

import pandas as pd
import math
import random
from participant import *
from helper_functions import *
from make_QR_code import *
from session_graph import *

# Define conversation topics (list A and list B - if using two conversation prompts)
conversation_topics_A = ['Topic A1', 'Topic A2', 'Topic A3', 'Topic A4', 'Topic A5', 'Topic A6', 'Topic A7', 'Topic A8']
conversation_topics_B = ['Topic B1', 'Topic B2', 'Topic B3', 'Topic B4', 'Topic B5', 'Topic B6', 'Topic B7', 'Topic B8']
# Shuffle topics to ensure random order each session
random.shuffle(conversation_topics_A)
random.shuffle(conversation_topics_B)

# Get session number and participant IDs (researcher enters these at the session start, based on actual attendance)
session_number = input('Please enter the full session number on the line below. \n')
done = False
correct = False
while not correct:
    attendance_ids = list()
    while not done:
        id_code = (input('Please enter a participant ID, including colour code. Press "d" when you are done. \n'))
        if str.upper(id_code) == 'D':
            done = True
        else:
            attendance_ids.append(str.upper(id_code))

    print(f'Current participants: {attendance_ids}')
    check_list = input('Is this list correct and complete? (y/n) \n')
    if str.upper(check_list) == 'Y':
        correct = True
    else:
        print('Rebuilding the list.')
        done = False

# for testing purposes, hardcoded session number and attendance ids
#session_number = 's999'
#attendance_ids = ['M101', 'B102', 'G103', 'P104', 'K105']

# How many rooms do we need? Calculate based on 2 chairs per room
num_rooms = math.ceil(len(attendance_ids) / 2)
# Build chairs within rooms
participant_count = 0
chair_list = []
for i in range(num_rooms):
    for j in range(2):
        if participant_count < len(attendance_ids):
            chair = float(f'{i+1}.{j+1}')
            chair_list.append(chair)
            participant_count += 1

if len(attendance_ids) % 2 != 0:
    # Odd number of participants, last chair is a waiting room chair (participant sits out a round in this chair)
    wait_room_chair = chair_list[-1]
else:
    wait_room_chair = None

# Build participant objects using entered attendance IDs
participant_list = []
for pid in attendance_ids:
    participant = Participant(pid[1:len(pid)], pid[0])
    participant_list.append(participant)
if wait_room_chair:
    # Add a dummy participant to represent an "interaction" in the waiting room
    participant = Participant('0', 'X')
    participant_list.append(participant)

# number of interaction rounds per participant 
# if even, n-1 rounds (participant does not talk to self); if odd, n rounds (participant in waiting room once)
if len(attendance_ids) % 2 == 0:
    total_interactions = len(participant_list) - 1
else:
    total_interactions = len(attendance_ids)

# Get lists of active conversation topics for the session
active_topics_A = get_active_conversation_topics(conversation_topics_A, total_interactions)
active_topics_B = get_active_conversation_topics(conversation_topics_B, total_interactions)

# Get round pairings
# The round data that gets saved will be a "double-entered" dataset (meaning there are 2 rows for each interaction,
# one where a participant is the target and one where they are the partner). To derive an unique row index, which
# increments by 2 each time, we set it to -2 for the first pass through the dataset.
row_id = -2  # start at -2 so that the index value in the final dataset begins at 0
d = []
nid_list = [participant.get_numid() for participant in participant_list]
round_list = nid_list.copy()
for interaction in range(total_interactions):
    print(f'Coding Interaction: {interaction + 1}')
    dyads = get_dyads(round_list)
    # For each dyad, assign conversation topics and chairs
    chair_indx = 0
    conv_indx = 0
    for dyad in dyads:
        conv_indx += 1
        if (dyad[0] == '0') or (dyad[1] == '0'):
            # One participant is in the waiting room (no conversation)
            topics = ('pass', 'pass')
            cur_chairs = (wait_room_chair, wait_room_chair)
        else:
            cur_chairs = (chair_list[chair_indx], chair_list[chair_indx + 1])
            if random.random() < 0.5:
                topics = (active_topics_A[interaction], active_topics_B[interaction])
            else: 
                topics = (active_topics_B[interaction], active_topics_A[interaction])
            chair_indx += 2
        this_dyad = []
        for i in range(2):
        # Assign conversation topics
            this_p = dyad[i]
            this_chair = cur_chairs[i]
            for participant in participant_list:
                if participant.get_numid() == this_p:
                    participant.set_topics(topics)
                    if interaction > 0:
                        if participant.get_chairs()[-1] == this_chair:
                            cur_chairs = (cur_chairs[1], cur_chairs[0])  # swap chairs if same as last time
                            this_chair = cur_chairs[i]
                    this_dyad.append(participant)
        p1 = this_dyad[0]
        p1.set_chair(cur_chairs[0])
        p2 = this_dyad[1]
        p2.set_chair(cur_chairs[1])
        row_id += 2   
        # First row of data
        d.append({'row_num': row_id,
                  'session_code': session_number,
                  'interaction_num': interaction + 1,
                  'conversation': conv_indx,
                  'room': p1.get_chairs()[-1] // 1,
                  'pid': p1.get_id(),
                  'num_id': p1.get_numid(),
                  'c_id': p1.get_colour_id(),
                  'p_colour': p1.get_colour(),
                  'p_colour_rgb': colour_tuples[p1.get_colour()],
                  'chair': p1.get_chairs()[-1],
                  'ptr_id': p2.get_id(),
                  'ptr_num_id': p2.get_numid(),
                  'ptr_c_id': p2.get_colour_id(),
                  'ptr_colour': p2.get_colour(),
                  'ptr_colour_rgb': colour_tuples[p2.get_colour()],
                  'ptr_chair': p2.get_chairs()[-1],
                  'topic_1': p1.get_topic_order()[-1][0],
                  'topic_2': p1.get_topic_order()[-1][1],
                  'qr_name': (p1.get_id() + '_' + str(interaction + 1)),
                  'ptr_qr_name': (p2.get_id() + '_' + str(interaction + 1))})
        # Second row of data (positions of participant and partner switched)
        d.append({'row_num': row_id + 1,
                  'session_code': session_number,
                  'interaction_num': interaction + 1,
                  'conversation': conv_indx,
                  'room': p2.get_chairs()[-1] // 1,
                  'pid': p2.get_id(),
                  'num_id': p2.get_numid(),
                  'c_id': p2.get_colour_id(),
                  'p_colour': p2.get_colour(),
                  'p_colour_rgb': colour_tuples[p2.get_colour()],
                  'chair': p2.get_chairs()[-1],
                  'ptr_id': p1.get_id(),
                  'ptr_num_id': p1.get_numid(),
                  'ptr_c_id': p1.get_colour_id(),
                  'ptr_colour_rgb': colour_tuples[p1.get_colour()],
                  'ptr_colour': p1.get_colour(),
                  'ptr_chair': p1.get_chairs()[-1],
                  'topic_1': p2.get_topic_order()[-1][0],
                  'topic_2': p2.get_topic_order()[-1][1],
                  'qr_name': (p2.get_id() + '_' + str(interaction + 1)),
                  'ptr_qr_name': (p1.get_id() + '_' + str(interaction + 1))})
    round_list = do_rotation(round_list)
    # rotate chairs for next round
    chair_list.append(chair_list.pop(0))
    chair_list.append(chair_list.pop(0))
    if wait_room_chair:
        chair_list.remove(wait_room_chair)
        chair_list.append(wait_room_chair)

# Convert to dataframe and save full session data
df = pd.DataFrame(d)
file_name = 'session_' + str(session_number) + '_full.csv'
df.to_csv(file_name, index=False)

for i in range(num_rooms):
    fn = 'room' + str(i+1) + '/room' + str(i+1) + '.xlsx'
    cur_room = df.copy()
    cur_room = cur_room[cur_room.room == i+1]
    cur_room.to_excel(fn, index=False)

make_QR(df, wait_room_chair)
make_round_graph(df)

# Output session summary
print(f'Session Number: {session_number}')
print(f'Total Interaction Rounds: {total_interactions}')
print(f'Total Active Participants = {len(attendance_ids)}')
print(f'Total Rooms in Use: {num_rooms}')
print(f'Chairs in Use: {chair_list}')
print(f'Waiting room chair: {wait_room_chair}')
print(f'Active Conversation Topics A: {active_topics_A}')
print(f'Active Conversation Topics B: {active_topics_B}')