# visualizer

import plotly.express as px
import pandas as pd


def make_round_graph(round_data):
    round_data = round_data.sort_values(by=['interaction_num', 'room', 'chair'])
    session_num = round_data.session_code[1]
    round_num = list()
    rooms = list()
    chairs = list()
    ptcps = list()
    for i in range(len(round_data)):
        if round_data['room'].iloc[i] < 2:
            round_num.append('Round: ' + str(int(round_data['interaction_num'].iloc[i])))
            rooms.append('Room: ' + str(int(round_data['room'].iloc[i])))
            chairs.append('Chair: ' + str(round_data['chair'].iloc[i]))
            ptcps.append(round_data['pid'].iloc[i])
        else:
            if round_data['pid'].iloc[i] != 0:
                round_num.append('Round: ' + str(int(round_data['interaction_num'].iloc[i])))
                rooms.append('Room: ' + str(int(round_data['room'].iloc[i])))
                chairs.append('Chair: ' + str(round_data['chair'].iloc[i]))
                ptcps.append(round_data['pid'].iloc[i])

    df = pd.DataFrame(dict(Round=round_num, Rooms=rooms, Chairs=chairs, Participants=ptcps))
    df['Session'] = 'Session: ' + session_num
    df['value'] = 1

    fig = px.treemap(df, path=['Session', 'Round', 'Rooms', 'Chairs', 'Participants'], values='value')
    fig.update_layout(margin=dict(t=50, l=50, r=50, b=50))
    fig.show()

