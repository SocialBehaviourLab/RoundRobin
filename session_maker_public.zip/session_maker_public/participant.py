#participant.py

class Participant:
    """Participants will be similar to nodes that hold several instance attributes for each person:
    the participant ID code (pid), the colour ID code (cid), and the colour definition (colour). In addition,
    participants will also carry session data including which chairs they are occupying in order and
    which conversation topics they are discussing in order and which they have not yet discussed (this allows us to
    check the topics and ensure that there are no duplicates). Participants will carry their own data with them
    wherever they go so that it is trackable. Importantly, once a participant is instantiated, we will never make
    changes to their identifying attributes although the session data will change.
    Therefore, there are getter methods for each identifier, along with a repr method
    for the class but there are only setter method for the session data (chairs and topics)."""

    def __init__(self, participant_id, colour_id):
        """Constructor for Participant class
        :param: participant_id: the participant id code (integer)
        :param: colour_id: the participant's colour id code (string)
        :param: num_topics: a list of indices that will be used to get the discussion topics (list)"""
        self._numid = participant_id
        self._cid = colour_id
        self._pid = f'{colour_id}{participant_id}'
        colours = {'M': 'magenta', 'B': 'blue', 'O': 'orange', 'R': 'red', 'K': 'black', 'G': 'green', 'P': 'purple',
                   'X': 'no_color'}
        self._colour = colours.get(colour_id[0])
        self._topics_order = []
        self._chairs_order = []

    def get_id(self):
        """Accessor method for participant ID code"""
        return self._pid

    def get_numid(self):
        """Accessor method for participant number ID code"""
        return self._numid

    def get_colour_id(self):
        """Accessor method for participant's colour ID code"""
        return self._cid

    def get_colour(self):
        """Accessor method for participant's colour name"""
        return self._colour

    def get_topic_order(self):
        """Accessor method for the topics in the participant's list"""
        return self._topics_order

    def get_chairs(self):
        """Accessor method for the ordered list of chairs"""
        return self._chairs_order

    def set_topics(self, next_topic):
        """Setter method for the next topic; pops the topic index out of the list and appends the next topic to
        the list of topic orders
        :param: next_topic: the index of the next topic to discuss."""
        self._topics_order.append(next_topic)

    def set_chair(self, next_chair):
        """Setter method for the next chair
        :param: next_chair: the number of the next chair in the sequence."""
        self._chairs_order.append(next_chair)

    def __repr__(self):
        """repr method for the class"""
        return f'Participant({self._pid, self._numid, self._cid, self._colour, self._topics_order, self._chairs_order})'
