# make_QR_code.py

import qrcode
from PIL import ImageTk

topics_dict = {'Topic A1': 'A1',
               'Topic A2': 'A2',
               'Topic A3': 'A3',
               'Topic A4': 'A4',
               'Topic A5': 'A5',
               'Topic A6': 'A6',
	           'Topic A7': 'A7',
	           'Topic A8': 'A8',
	           'Topic B1': 'B1',
               'Topic B2': 'B2',
               'Topic B3': 'B3',
               'Topic B4': 'B4',
               'Topic B5': 'B5',
               'Topic B6': 'B6',
	           'Topic B7': 'B7',
	           'Topic B8': 'B8',
               'pass': 'pass'
               }


def make_QR(my_data_frame, wait_room_chair=None):
    pids = set(my_data_frame['num_id'])
    for participant in pids:
        if int(participant) > 0:
            d = my_data_frame.copy()
            d = d[d.num_id == participant]
            d.reset_index(drop=True, inplace=True)
            for i in range(len(d)):
                pid = d.loc[i, 'pid']
                ptrID = d.loc[i, 'ptr_id']
                StudySessionID = d.loc[i, 'interaction_num']
                ConversationNum = d.loc[i, 'conversation']
                qrcode_colour = d.loc[i, 'p_colour']
                qrcode_name = d.loc[i, 'qr_name'] + '.png'
                current_room = int(d.loc[i, 'room'])
                if i < (len(d)-1):
                    room = current_room
                    chair_num = d.loc[i+1, 'chair']
                    if chair_num % 1 > .15:
                        chair = 2
                    else:
                        chair = 1
                else:
                    room = 'Please return to your original computer room.'
                    chair = '--'
                if wait_room_chair:
                    if room == wait_room_chair:
                        room = str(wait_room_chair[0])
                        chair = '1'
                t1 = d.loc[i, 'topic_1']
                t2 = d.loc[i, 'topic_2']
                topic1 = topics_dict.get(t1)
                topic2 = topics_dict.get(t2)

                piq_link = 'https://www.questionnairehost.com/questionnaire'
                qr_info = piq_link + '?PID=' + str(pid) + '&StudySessionID=' + str(StudySessionID) + \
                          '&ConversationNum=' + str(ConversationNum) + '&ptrID=' + str(ptrID) + \
                          '&room=' + str(room) + '&chair=' + str(chair) + '&topic1=' + topic1 + '&topic2=' + topic2
                colours = {'magenta': (255, 0, 255), 'blue': (0, 128, 255), 'orange': (255, 128, 0),
                           'red': (255, 0, 64), 'black': (0, 0, 0), 'green': (2, 169, 47), 'purple': (148, 0, 211)}
                qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
                qr.add_data(qr_info)
                qr.make(fit=True)
                qrcode_colour_tuple = colours[qrcode_colour]
                img = qr.make_image(fill_color=qrcode_colour_tuple, back_color=(255, 255, 255))
                file_name = 'room' + str(current_room) + '/images/' + qrcode_name
                img.save(file_name)
