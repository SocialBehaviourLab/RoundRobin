# helper_functions.py

colour_tuples = {'magenta': (255, 15, 207), 'blue': (0, 128, 255), 'orange': (255, 128, 0), 'red': (255, 0, 64),
           'black': (0, 0, 0), 'green': (2, 169, 47), 'purple': (138, 43, 226), 'no_color': (255, 255, 255)}


def get_active_conversation_topics(conv_topics, num_interactions):
    """shuffles and returns the correct number of conversation topics for the session.
     Runs once at the start of the scheduler.
     :param: conv_topics: the list of conversation topics for the session (list)
     :param: num_interactions: the number of interactions that will need unique discussion topics (integer)
     :return: shuffled list of correct number of conversation topics (list)"""
    while len(conv_topics) > num_interactions:
        conv_topics.pop()
    return conv_topics


def get_dyads(my_participant_list):
    """Assigns individual participants to dyads based on their position in the list.
     :param: my_participant_list: a list of integer participant IDs (list)
     :return: a list of dyads for this round (list)
     """
    dyad_list = []
    list_split = int(len(my_participant_list) / 2)
    for i in range(list_split):
        partner_1 = my_participant_list[i]
        partner_2 = my_participant_list[i + list_split]
        dyad_list.append((partner_1, partner_2))
    return dyad_list


def do_rotation(my_list):
    """Rotates positions in the list, holding the first one constant. Uses the scheduling algorithm located here:
    https://en.wikipedia.org/wiki/Round-robin_tournament#Scheduling_algorithm
    :param: my_list: list of integer participant IDs (list)
    :return: rotated list: list of integer participant IDs post-rotation (list)"""
    list_split = int(len(my_list) / 2)
    last_item_number = len(my_list)
    rotated_list = list()
    rotated_list.append(my_list[0])  # keep first participant in position 1
    rotated_list.append(my_list[list_split])  # next, move the person at the split of the list to position 2
    for i in range(1, list_split-1, 1):  # next, move the rest of the first half of the list to positions in order
        rotated_list.append(my_list[i])
    count = list_split+1
    for i in range(last_item_number - (list_split+1)):  # next, move the last half of the participants to positions
        rotated_list.append(my_list[count])
        count += 1
    rotated_list.append(my_list[list_split-1])  # last participant is the last one in the first half of list
    return rotated_list