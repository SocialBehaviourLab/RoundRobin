# session_creator.py

# This function is the workhorse. It creates participants, based on the ID list; attaches data to each participant;
# and then generates the data for each conversation round. 

import os
import pandas as pd
import numpy as np
import math
import random
from participant import *
from helper_functions import *

def generate_session(session_number, attendance_ids, prompt, topic_lists, num_topics, topic_dict, manip, conditions, manip_dict):
    # How many rooms do we need? Calculate based on 2 chairs per room
    num_rooms = math.ceil(len(attendance_ids) / 2)
    # Build chairs within rooms
    participant_count = 0
    chair_list = []
    for i in range(num_rooms):
        for j in range(2):
            if participant_count < len(attendance_ids):
                chair = float(f'{i+1}.{j+1}')
                chair_list.append(chair)
                participant_count += 1

    if len(attendance_ids) % 2 != 0:
    # Odd number of participants, last chair is a waiting room chair (participant sits out a round in this chair)
        wait_room_chair = chair_list[-1]
    else:
        wait_room_chair = None

    # Build participant objects using entered attendance IDs
    participant_list = []
    for pid in attendance_ids:
        participant = Participant(pid[1:len(pid)], pid[0])
        participant_list.append(participant)
    if wait_room_chair:
        # Add a dummy participant to represent an "interaction" in the waiting room
        participant = Participant('0', 'X')
        participant_list.append(participant)

    # number of interaction rounds per participant 
    # if even, n-1 rounds (participant does not talk to self); if odd, n rounds (participant in waiting room once)
    if len(attendance_ids) % 2 == 0:
        total_interactions = len(participant_list) - 1
    else:
        total_interactions = len(attendance_ids)

    # Get lists of active conversation topics for the session
    if prompt:
        active_topics = []
        for topic_list in topic_lists:
            new_list = get_active_conversation_topics(topic_list, total_interactions)
            active_topics.append(new_list)

    # If using manipulation that changes for each participant in each round, this sets up the order of the condition manipulations
    # on a participant-by-participant basis across the rounds. This includes an assignment of a manipulation during the "waiting room"
    # time which balances the manipulations across interaction rounds (but would not get applied if it were not needed).
    if manip:
        # to ensure balanced randomization of manipulation conditions across interactions
        for participant in participant_list:
            random.shuffle(conditions)
            m_counter = 0
            for i in range(total_interactions):
                participant.set_manip(conditions[m_counter])
                m_counter += 1
                if m_counter >= len(conditions):
                    random.shuffle(conditions)
                    m_counter = 0
    # Get round pairings
    # The round data that gets saved will be a "double-entered" dataset (meaning there are 2 rows for each interaction,
    # one where a participant is the target and one where they are the partner). To derive an unique row index, which
    # increments by 2 each time, we set it to -2 for the first pass through the dataset.
    row_id = -2  # start at -2 so that the index value in the final dataset begins at 0
    d = []
    nid_list = [participant.get_numid() for participant in participant_list]
    round_list = nid_list.copy()    
    for interaction in range(total_interactions):
        print(f'Coding Interaction: {interaction + 1}')
        dyads = get_dyads(round_list)
        # For each dyad, assign conversation topics and chairs
        chair_indx = 0
        conv_indx = 0
        for dyad in dyads:
            conv_indx += 1
            if (dyad[0] == '0') or (dyad[1] == '0'):
                # One participant is in the waiting room (no conversation)
                if prompt: 
                    itx_prompts = []
                    for k in range(num_topics):
                        itx_prompts.append('pass')
                    topics = tuple(itx_prompts)
                cur_chairs = (wait_room_chair, wait_room_chair)
            else:
                cur_chairs = (chair_list[chair_indx], chair_list[chair_indx + 1])
                if prompt: 
                    itx_prompts = []
                    for k in range(num_topics):
                        itx_prompts.append(active_topics[k][interaction])
                    random.shuffle(itx_prompts)
                    topics = tuple(itx_prompts)
                chair_indx += 2
            this_dyad = []
            for i in range(2):
            # Assign conversation topics / chairs
                this_p = dyad[i]
                this_chair = cur_chairs[i]
                for participant in participant_list:
                    if participant.get_numid() == this_p:
                        if prompt:
                            participant.set_topics(topics)
                        if interaction > 0:
                            if participant.get_chairs()[-1] == this_chair:
                                cur_chairs = (cur_chairs[1], cur_chairs[0])  # swap chairs if same as last time
                                this_chair = cur_chairs[i]
                        this_dyad.append(participant)
            p1 = this_dyad[0]
            p1.set_chair(cur_chairs[0])
            p2 = this_dyad[1]
            p2.set_chair(cur_chairs[1])
            row_id += 2   
            # First row of data
            row1 = {'row_num': row_id,
                    'session_code': session_number,
                    'interaction_num': interaction + 1,
                    'conversation': conv_indx,
                    'room': p1.get_chairs()[-1] // 1,
                    'pid': p1.get_id(),
                    'num_id': p1.get_numid(),
                    'c_id': p1.get_colour_id(),
                    'p_colour': p1.get_colour(),
                    'p_colour_rgb': colour_tuples[p1.get_colour()],
                    'chair': p1.get_chairs()[-1],
                    'ptr_id': p2.get_id(),
                    'ptr_num_id': p2.get_numid(),
                    'ptr_c_id': p2.get_colour_id(),
                    'ptr_colour': p2.get_colour(),
                    'ptr_colour_rgb': colour_tuples[p2.get_colour()],
                    'ptr_chair': p2.get_chairs()[-1],
                    'qr_name': (p1.get_id() + '_' + str(interaction + 1)),
                    'ptr_qr_name': (p2.get_id() + '_' + str(interaction + 1))}
            if prompt:
                t = p1.get_topic_order()
                t = t[-1]
                for k in range(len(t)):
                    key = 'topic_' + str(k + 1)
                    value = t[k]
                    row1[key] = value
            if manip:
                m = p1.get_manips()
                row1['manip_cond'] = m[interaction]
            d.append(row1)
            # Second row of data (positions of participant and partner switched)
            row2 = {'row_num': row_id + 1,
                    'session_code': session_number,
                    'interaction_num': interaction + 1,
                    'conversation': conv_indx,
                    'room': p2.get_chairs()[-1] // 1,
                    'pid': p2.get_id(),
                    'num_id': p2.get_numid(),
                    'c_id': p2.get_colour_id(),
                    'p_colour': p2.get_colour(),
                    'p_colour_rgb': colour_tuples[p2.get_colour()],
                    'chair': p2.get_chairs()[-1],
                    'ptr_id': p1.get_id(),
                    'ptr_num_id': p1.get_numid(),
                    'ptr_c_id': p1.get_colour_id(),
                    'ptr_colour_rgb': colour_tuples[p1.get_colour()],
                    'ptr_colour': p1.get_colour(),
                    'ptr_chair': p1.get_chairs()[-1],
                    'qr_name': (p2.get_id() + '_' + str(interaction + 1)),
                    'ptr_qr_name': (p1.get_id() + '_' + str(interaction + 1))}
            if prompt:
                t = p2.get_topic_order()
                t = t[-1]
                for k in range(len(t)):
                    key = 'topic_' + str(k + 1)
                    value = t[k]
                    row2[key] = value
            if manip:
                m = p2.get_manips()
                row2['manip_cond'] = m[interaction]
            d.append(row2)
        round_list = do_rotation(round_list)
        # rotate chairs for next round
        chair_list.append(chair_list.pop(0))
        chair_list.append(chair_list.pop(0))
        if wait_room_chair:
            chair_list.remove(wait_room_chair)
            chair_list.append(wait_room_chair)

    # Convert to dataframe and save full session data
    df = pd.DataFrame(d)
    if manip:
        file_name = 'session_' + str(session_number) + '_NONBLIND.csv'
        df.to_csv(file_name, index=False)
        df2 = df.drop(columns=['manip_cond'])
        file_name2 = 'session_' + str(session_number) + '_BLIND.csv'
        df2.to_csv(file_name2, index=False)
    else:
        file_name = 'session_' + str(session_number) + '_full.csv'
        df.to_csv(file_name, index=False)

    for i in range(num_rooms):
        path = 'room' + str(i+1)
        if not os.path.exists(path):
            os.makedirs(path)
            os.makedirs(path + '/images')
        fn = 'room' + str(i+1) + '/room' + str(i+1) + '.xlsx'
        cur_room = df.copy()
        cur_room = cur_room[cur_room.room == i+1]
        cur_room.to_excel(fn, index=False)

    return df, wait_room_chair