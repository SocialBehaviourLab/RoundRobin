# make_QR_code.py

import qrcode
from PIL import ImageTk

def make_QR(my_data_frame, wait_room_chair=None, num_prompts=0, topic_dict=None, is_manip=False, manip_dict=None, piq_link='https://www.questionnairehost.com/questionnaire'):
    pids = set(my_data_frame['num_id'])
    for participant in pids:
        if int(participant) > 0:
            d = my_data_frame.copy()
            d = d[d.num_id == participant]
            d.reset_index(drop=True, inplace=True)
            for i in range(len(d)):
                pid = d.loc[i, 'pid']
                ptrID = d.loc[i, 'ptr_id']
                StudySessionID = d.loc[i, 'interaction_num']
                ConversationNum = d.loc[i, 'conversation']
                qrcode_colour = d.loc[i, 'p_colour']
                qrcode_name = d.loc[i, 'qr_name'] + '.png'
                current_room = int(d.loc[i, 'room'])
                if i < (len(d)-1):
                    room = current_room
                    chair_num = d.loc[i+1, 'chair']
                    if chair_num % 1 > .15:
                        chair = 2
                    else:
                        chair = 1
                else:
                    room = 'Please return to your original computer.'
                    chair = '--'
                if wait_room_chair:
                    if room == wait_room_chair:
                        room = str(wait_room_chair[0])
                        chair = '1'
                t_info = ''
                if num_prompts > 0:
                    for j in range(num_prompts):
                        cur_t = 'topic_' + str(j + 1)
                        t = d.loc[i, cur_t]
                        t_val = topic_dict.get(t)
                        t_info += '&' + cur_t + '=' + t_val 
                m_info = ''
                if is_manip:
                    m = d.loc[i, 'manip_cond']
                    m_val = manip_dict.get(m)
                    m_info += '&manip_cond=' + m_val 
                          
                qr_info = piq_link + '?PID=' + str(pid) + '&StudySessionID=' + str(StudySessionID) + \
                          '&ConversationNum=' + str(ConversationNum) + '&ptrID=' + str(ptrID) + \
                          '&room=' + str(room) + '&chair=' + str(chair) + t_info + m_info
                colours = {'magenta': (255, 0, 255), 'blue': (0, 128, 255), 'orange': (255, 128, 0),
                           'red': (255, 0, 64), 'black': (0, 0, 0), 'green': (2, 169, 47), 'purple': (148, 0, 211)}
                qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
                qr.add_data(qr_info)
                qr.make(fit=True)
                qrcode_colour_tuple = colours[qrcode_colour]
                img = qr.make_image(fill_color=qrcode_colour_tuple, back_color=(255, 255, 255))
                file_name = 'room' + str(current_room) + '/images/' + qrcode_name
                img.save(file_name)