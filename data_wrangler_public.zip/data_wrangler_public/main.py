# Data Wrangler

import os
import shutil
import pandas as pd
from wrangler_functions import *

# This script organizes all the session files into a working file structure. It should run after data collection is complete. 
# First, get a list of the basic folders (the place we throw things in a hurry during data collection)
path = '.' # Current directory
subfolders = [file.name for file in os.scandir(path) if file.is_dir()]

# Next, we need to build a list of the basic session files and video files (we will assume a summary/scored questionnaire file exists)
session_files = []
video_files = []
for folder in subfolders:
    folder_path = os.path.join(path, folder)
    if 'questionnaire' in folder:
        questionnaire_folder = folder_path
    for file in os.listdir(folder_path):
        if 'session_' in file:
            session_files.append(os.path.join(folder_path, file))
        if 'round' in file:
            video_files.append(os.path.join(folder_path, file))

# Now, we will create a new main data directory to hold the organized data
os.makedirs('Data', exist_ok=True)
os.makedirs('Data/Compiled_Questionnaires', exist_ok=True) # Create compiled questionnaires folder
# Copy the summarized questionnaire files into the main data directory
# Make a note of the file paths for later use
qf = questionnaire_folder + '/SummaryQuestionnaires'
for file in os.listdir(qf):
    if file.endswith('.csv'):
        shutil.copy(os.path.join(qf, file), os.path.join('Data/Compiled_Questionnaires', file))
        if 'interaction' in file: # post-interaction questionnaires
            interaction_questionnaire_file = os.path.join('Data/Compiled_Questionnaires', file)
        if 'summary' in file: # general questionnaire data including demographics
            summary_questionnaire_file = os.path.join('Data/Compiled_Questionnaires', file)

# Now, we will loop through each session file, create a folder architecture for it, and move the relevant files into that structure
session_file_destinations = []
for session_file in session_files:
    d = pd.read_csv(session_file)
    cur_sess = d['session_code'][0]
    print(f'\nPreparing files: {cur_sess}')
    # make a new folder for this session within a data directory
    sess_dir = './Data/' + cur_sess
    os.makedirs(sess_dir, exist_ok=True)
    # Record the file path for the session file destination (it will be saved here later); add to list of session file destinations
    session_file_dest = os.path.join(sess_dir, os.path.basename(session_file))
    session_file_destinations.append(session_file_dest)
    # make subfiles for different data types within this session folder
    os.makedirs(sess_dir + '/session_videos', exist_ok=True)
    # The folders below are not in use for this demonstration project, but are here for future use
    #os.makedirs(sess_dir + '/transcripts', exist_ok=True)
    #os.makedirs(sess_dir + '/video_coding', exist_ok=True)

    # Within the set of session files, get a list of video files for this session
    session_video_files = []
    print(f'Moving video files: {cur_sess}')
    for i in range(len(video_files)):
        if cur_sess in video_files[i]:
            session_video_files.append(video_files[i])
    vid_dir = sess_dir + '/session_videos'
    # Now, we will move and rename the video files for this session (return dataframe with each video's filing status)
    d = video_file(session_video_files, vid_dir, d)

    # Finally, save the recoded dataframe to the session folder (this file now contians the data catalogue)
    d.to_csv(session_file_dest, index=False)

# Finally, we will compile the questionnaire data and check for errors and missing data
# The questionnaires will be pulled from the summary questionnaire files, checked against the session data and 
# aggregated into a single file for the study (this makes it easier to analyze later). Data will be recorded as 
# either corectly matched, mismatched, or missing. 
#
# To allow for user error (e.g., a participant using the wrong QR code), the questionnaires contain participant/partner IDs 
# that are passed in via the QR code link AND participant-entered versions of those IDs. This redundancy allows us to
# check for mismatches and missing data and further checks/edits post-hoc.
#
# NOTE: All data in the compiled questionnaires documents for this project file is synthesized.

# Load the summary and post-interaction questionnaire datafiles
print(f'\nCombining all questionnaires')
df_summary = pd.read_csv(summary_questionnaire_file)
cols_to_keep = ['age', 'gender', 'Questionnaire_A', 'Questionnaire_B']
df_interaction = pd.read_csv(interaction_questionnaire_file)
comb_quest_list = []
for session_file in session_file_destinations:
    d = combine_questionnaires(df_interaction, df_summary, session_file, cols_to_keep)
    comb_quest_list.append(d)
all_data = pd.concat(comb_quest_list, ignore_index=True)
# Save the compiled questionnaire data to the compiled questionnaires folder
all_data.to_csv('./Data/Compiled_Questionnaires/Compiled_Questionnaires.csv', index=False)

print('\n')