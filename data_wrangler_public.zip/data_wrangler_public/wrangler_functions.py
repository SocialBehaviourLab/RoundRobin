# helper functions for data wrangler

import os
import shutil
import pandas as pd

def video_file(session_videos, video_directory, data):
    data['video_filed'] = 0
    data['video_path'] = ''
    for video_path in session_videos:
        # use file from video path to determine which round, room, and chair
        r = str(video_path).find('round') + 5
        o = str(video_path).find('room') + 4
        c = str(video_path).find('chair') + 5
        round_num = int(str(video_path)[r])
        room_num = int(str(video_path)[o])
        chair_num = int(str(video_path)[c])
        chair_num = float(f'{room_num}.{chair_num}')
        # get the matching line from dataframe
        t = data[(data['interaction_num'] == round_num) & 
                 (data['room'] == room_num) & 
                 (data['chair'] == chair_num)]
        vid_fn = video_directory + '/' + t['session_code'].values[0] + '_tgt_' + t['pid'].values[0] + '_ptr_' + t['ptr_id'].values[0] + '.mov'
        try:
            shutil.move(video_path, vid_fn)
            data.at[t.index[0], 'video_filed'] = 1
            data.at[t.index[0], 'video_path'] = vid_fn
        except shutil.Error as e:
            print(f"Error: {e}")
        except FileNotFoundError:
            print(f"Error: Source file '{video_path}' not found.")
    return data

    
def combine_questionnaires(piq, sum_dat, session, cols_to_add):
    # First, load the session data
    session_data = pd.read_csv(session)
    cur_sess = session_data['session_code'][0]
    print(f'Session: {cur_sess}')
    #ids = session_data['pid'].unique().tolist()
    #ids = [id for id in ids if 'X' not in id] # remove any placeholder IDs (only present if there is an odd number of participants)
    # Then, add correct columns to piq (post-interaction questionnaire data); one column for participant, one for partner
    piq = piq[piq['session'] == cur_sess].copy()
    piq.reset_index(inplace=True, drop=True)
    prefix = ['p_', 'ptr_']
    # add empty columns to piq if they don't already exist
    for p in prefix:
        for col in cols_to_add:
            col_name = p + col
            if col_name not in piq.columns:
                piq[col_name] = None
    for i in range(len(piq)):
        pid = piq.at[i, 'pid']
        # get the summary questionnaire data for this pid
        summary_q = sum_dat[sum_dat['pid'] == pid]
        # for each of the columns to add, get the value from the appropriate dataframe and add to session_data
        for col in cols_to_add:
            val = summary_q[col].values[0]
            col_name = 'p_' + col
            # assign this value to all rows in session_data for this pid
            piq.at[i, col_name] = val
        # now do the same for the partner
        ptr_id = piq.at[i, 'ptr_id']
        summary_q_ptr = sum_dat[sum_dat['pid'] == ptr_id]
        for col in cols_to_add:
            val = summary_q_ptr[col].values[0]
            col_name = 'ptr_' + col
            # assign this value to all rows in session_data for this ptr_id
            piq.at[i, col_name] = val
    return piq