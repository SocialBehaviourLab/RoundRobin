# questionnaire checker

# One of the issues that arises in the context of round-robin interaction studies is ensuring that the questionnaire data
# are correctly matched to the session data. This is particularly important when participants complete post-interaction
# questionnaires. Here, we have asked participants to scan a QR code at the end of each interaction to access the relevant
# questionnaire. The QR code passes data into the questionnaire that is used for tracking/matching purposes. 
# However, participants may scan the wrong QR code, leading to mis-coded data. To help mitigate this issue, we ask
# participants to enter their participant ID and their partner's participant ID at the start of each questionnaire.
# This allows us to cross-check the QR code data against the participant-entered data to identify potential mismatches.

# This script checks for mismatches and missing data in both the basic and post-interaction questionnaires.
# For example, we should have one post-interaction questionnaire for each participant for each interaction they took part in. 
# We should also have one line of summary data (e.g., relevant demographic variables, scored questionnaires) per participant.
# The script adds flags to the session file indicating whether the questionnaire data is correctly matched for each participant.
# If it is not, the flags indicate that a researcher should check the data against their session notes or other sources of 
# information to verify and correct these issues. 
#
# FOR BEST RESULTS, RUN THIS BEFORE WRANGLING THE DATA.

import os
import pandas as pd

path = '.' # Current directory
subfolders = [file.name for file in os.scandir(path) if file.is_dir()]

# Build a list of the session files and get the questionnaire folder path
session_files = []
for folder in subfolders:
    folder_path = os.path.join(path, folder)
    if 'questionnaire' in folder:
        questionnaire_folder = folder_path
    for file in os.listdir(folder_path):
        if 'session_' in file:
            session_files.append(os.path.join(folder_path, file))

# Get paths of both the scored summary questionnaires and the scored post-interaction questionnaire (which we assume exists)
qf = questionnaire_folder + '/SummaryQuestionnaires'
for file in os.listdir(qf):
    if file.endswith('.csv'):
        if 'interaction' in file: # post-interaction questionnaires
            interaction_questionnaire_file = os.path.join(qf, file)
        if 'summary' in file: # general questionnaire data including demographics
            summary_questionnaire_file = os.path.join(qf, file)

# Open main questionnaire files
sum_q_df = pd.read_csv(summary_questionnaire_file) # summarized questionnaire data
piq_df = pd.read_csv(interaction_questionnaire_file) # summarized post-interaction questionnaire data

# The summary data file may be edited if so, we will resave it without overwriting
do_resave = 0
edited_fn = summary_questionnaire_file[0:-4] + '_edited.csv'

# Walk through the sessions and check the data
print(f'\n')
for session_file in session_files:
    d = pd.read_csv(session_file)
    cur_sess = d['session_code'][0]
    sess_piqs = piq_df[piq_df['session'] == cur_sess]
    # Unique session IDs (exlcuding filler participant if needed)
    pids = d['pid'].unique().tolist()
    pids = [item for item in pids if 'X' not in item]

    # Is summary data present?
    print(f'Checking summary data for session {cur_sess}.')
    d['summary_qs_present'] = 0
    for pid in pids:
        s = sum_q_df[sum_q_df['pid'] == pid]
        if len(s) == 0:
            print(f'\n- Summary questionnaires not found in file for: {pid}\n')
            # add a filler line in summary questionnaires for this PID
            # can be manually filled in later (but will also propagate through other code with missing data value)
            cols = s.columns.tolist()
            new_dat = {}
            for col in cols:
                new_dat[col] = -999 # Code for missing data
            new_dat['pid'] = pid
            new_dat['num_id'] = pid[1:len(pid)]
            new_dat['session'] = d['session_code'][0]
            row = pd.DataFrame([new_dat])
            sum_q_df = pd.concat([sum_q_df, row], ignore_index=True)
            do_resave = 1
        mask = d['pid'] == pid
        indices = d[mask].index.tolist()
        for indx in indices:
            d.loc[indx, 'summary_qs_present'] = len(s) # add value to dataset (1 if present)
    # Are post interaction questionnaires present and matched to each interaction
    print(f'Checking post-interaction questionnaires for session {cur_sess}.')
    d['piq_present'] = 0
    for i in range(len(d)):
        cur_p = d.loc[i, 'pid']
        cur_ptr = d.loc[i, 'ptr_id']
        if ('X' not in cur_p) & ('X' not in cur_ptr):
            cur_piq = piq_df[(piq_df['pid'] == cur_p) & (piq_df['ptr_id'] == cur_ptr)]
            d.loc[i, 'piq_present'] = len(cur_piq)
            if len(cur_piq) != 1:
                rows = cur_piq['row_num'].values
                num_rows = len(rows)
                if num_rows > 1:
                    print(f'\n- Session: {cur_sess}; Target: {cur_p}; Partner: {cur_ptr}: \n- There are {num_rows} post-interaction questionnaires in the dataset for this interaction.\n- Was the wrong QR code scanned? Check row numbers: {rows}\n')
                else: 
                    print(f'\n- Session: {cur_sess}; Target: {cur_p}; Partner: {cur_ptr}: \n- There are {num_rows} post-interaction questionnaires in the dataset for this interaction.\n')
    d.to_csv(session_file, index=False)
# Resave summary data
if do_resave:
    sum_q_df.to_csv(edited_fn, index=False)

